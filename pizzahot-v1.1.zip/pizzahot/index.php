<!DOCTYPE html>
<html>
<head>
	<title>Pizza Hot</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/all.min.css">

	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.cycle2.min.js"></script>
</head>
<body>
	<header>
		<div class="container">
			<a href="index.php" title="Home" class="header-logo">
				<img src="imagens/logo.png" alt="Pizza Hot" title="Pizza Hot">
			</a>

			<button type="button" class="header-button" onclick="menu()">
				<i class="fas fa-bars"></i>
			</button>

			<nav class="header-menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="sobre">Sobre</a>
					</li>
					<li>
						<a href="cardapio">Cardápio</a>
					</li>
					<li>
						<a href="contato">Contato</a>
					</li>
				</ul>
			</nav>


		</div>
	</header>

	<div class="cycle-slideshow">
		<img src="imagens/banner.jpg" class="w-100">
		<img src="imagens/banner2.jpg" class="w-100">
	</div>

	<main class="container">
		<h1>Nosso Cardápio</h1>
		<h2>As melhores pizzas</h2>

		<div class="row">
			<div class="col">
				<img src="imagens/pizza1.jpg" class="w-100">
			</div>
			<div class="col">
				<img src="imagens/pizza1.jpg" class="w-100">
			</div>
			<div class="col">
				<img src="imagens/pizza1.jpg" class="w-100">
			</div>
			<div class="col">
				<img src="imagens/pizza1.jpg" class="w-100">
			</div>
		</div>
	</main>

	<div class="sobre">
		<div class="container">
			<div class="row">
				<div class="col">
					<img src="imagens/empresa.jpg" class="w-100">
				</div>
				<div class="col-4">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				</div>
			</div>
		</div>
	</div>

	<footer>
		<p>Desenvolvido por Tidinha</p>
	</footer>

	<script type="text/javascript">
		function menu() {
			$(".header-menu").toggle();
		}
	</script>

</body>
</html>